package webserver;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.xml.bind.DatatypeConverter;

public class Method {

	private final String PATH_SEPARATOR = "/";
	public enum MethodType {GET, HEAD, POST, PUT}
	private final String PATH = "webserver" + PATH_SEPARATOR + "pages";
	private final File SHARED_FOLDER = new File(PATH);
	private final String ALLOWED_MEDIA_TYPE = "png/jpg/jpeg";

	/**
	 * GET method to return index.html path
	 * @param path
	 * @return
	 * @throws FileNotFoundException
	 * @throws Exception
	 * @throws SecurityException
	 */
	public File GET(String path)
			throws FileNotFoundException, Exception, SecurityException {

		if (path.equals("/")) {
			path += "index.htm";
		}

		if (path.endsWith("htm") && !new File(SHARED_FOLDER, path).exists()) {
			path += "l";
		}

		else if (path.endsWith("html") && !new File(SHARED_FOLDER, path).exists()) {
			path = path.substring(0, path.length() - 1);
		}

		else if (path.charAt(path.length() - 1) != '/' && path.split("\\.").length == 0) {
			path += "/";
		}

		System.out.println("SHARED_FOLDER " + SHARED_FOLDER);
		System.out.println("SHARED_FOLDER path " + PATH +  path);
		File file = new File(PATH +  path);
		System.out.println(file.exists());
		/** 
		 * return if file exist otherwise throw file not found exception
		 */
		if(file.exists()) {
			return file;
		}
		throw new FileNotFoundException();
	}


	/**
	 * Post method to upload image content to the disk
	 * @param requestParser
	 * @throws IOException
	 * @throws Exception
	 */
	public void POST(RequestParser requestParser) throws IOException, Exception {

		if (!ALLOWED_MEDIA_TYPE.contains(requestParser.getUploadedFileExtension())) {
			throw new Exception();
		}

		byte[] imageBytes = DatatypeConverter.parseBase64Binary(requestParser.getBody());

		File imageFile = new File(SHARED_FOLDER,
				PATH_SEPARATOR + requestParser.getUploadedFileName());

		FileOutputStream fop = new FileOutputStream(imageFile, false);
		fop.write(imageBytes);
		fop.flush();
		fop.close();
	}

	/**
	 * Method to get Method type whether Get or Post
	 * @param method
	 * @return
	 * @throws Exception
	 */
	public static MethodType getEnumMethodType(String method) throws Exception {

		for (MethodType m : MethodType.values()) {
			if (method.equals(m.name())) {
				return m;
			}
		}
		throw new Exception();
	}
}