package webserver;

import java.io.BufferedReader;
import java.io.IOException;

import webserver.Method.MethodType;

public class RequestParser {

	private MethodType type;
	private String path;
	private final String HTTP_VERSION = "HTTP/1.1";
	private boolean connectionClosed = false;
	private long contentLength = 0;
	private String body;
	private String uploadedFileName;
	private String uploadedFileExtension;

	public RequestParser() {
	}

	/**
	 * Method to parse header and body information 
	 * @param reader
	 * @return
	 * @throws Exception
	 */
	public RequestParser parse(BufferedReader reader)
			throws Exception {

		parseHeader(readHeader(reader));

		/*** if content length is greater than zero then read then read the content body ***/ 
		if (contentLength > 0) {
			parseBody(readBody(reader));
		}

		return new RequestParser(type, path, body, connectionClosed, uploadedFileName, uploadedFileExtension);
	}

	/***
	 * Method to parser header information
	 * @param header
	 * @throws Exception
	 */
	private void parseHeader(String header) throws Exception {

		String[] totalLines = header.split("\r\n");

		String[] request = totalLines[0].split(" ");

		if (request.length != 3) {
			throw new Exception();
		}

		if (!request[2].equals(HTTP_VERSION)) {
			throw new Exception();
		}

		for (int i = 1; i < totalLines.length; i++) {
			if (totalLines[i].startsWith("Connection")) {
				this.connectionClosed = totalLines[i].split(": ")[1].equals("close");
				break;
			}
		}

		if (type != Method.MethodType.PUT) {
			this.type = Method.getEnumMethodType(request[0]);
		}

		this.path = request[1];
	}

	/***
	 * Method to read header and get the content length to read the body content
	 * @param reader
	 * @return
	 * @throws IOException
	 * @throws NumberFormatException
	 */
	private String readHeader(BufferedReader reader) throws IOException, NumberFormatException {

		StringBuilder header = new StringBuilder();

		while (true) {

			String line = reader.readLine();

			if (line == null || line.equals("\r\n") || line.isEmpty() || line.equals("")) {
				break;
			}

			header.append(line + "\r\n");

			/*** checking content-length field and fetching length of the content ***/
			if (line.startsWith("Content-Length")) {
				contentLength = Integer.parseInt(line.substring(16));
			}
		}

		return header.toString();
	}

	/***
	 * parsing body of the content 
	 * @param body
	 * @throws ArrayIndexOutOfBoundsException
	 */
	private void parseBody(String body) throws ArrayIndexOutOfBoundsException {

		this.uploadedFileName = body.split("=")[0];

		this.body = body.split("base64,")[1];
		this.uploadedFileExtension = body.split(":")[1].split(";")[0].split("/")[1];
	}

	/***
	 * reading body for the content using content length
	 * @param reader
	 * @return
	 * @throws IOException
	 */
	private String readBody(BufferedReader reader) throws IOException {

		StringBuilder body = new StringBuilder();

		for (int i = 0; i < contentLength; i++) {
			char ch = (char) reader.read();

			if (ch == '%') {
				ch = (char) Integer.parseInt("" + (char) reader.read() + "" + (char) reader.read(), 16);
				i += 2;
			}

			body.append(ch);
		}

		return body.toString();
	}
	
	/***
	 * Request parser constructor  
	 * @param type
	 * @param path
	 * @param body
	 * @param connectionClosed
	 * @param uploadedFileName
	 * @param uploadedFileExtension
	 */
	private RequestParser(Method.MethodType type, String path, String body, boolean connectionClosed, String uploadedFileName,
			String uploadedFileExtension) {

		this.type = type;
		this.path = path;
		this.body = body;
		this.connectionClosed = connectionClosed;
		this.uploadedFileName = uploadedFileName;
		this.uploadedFileExtension = uploadedFileExtension;
	}

	public Method.MethodType getMethodType() {
		return type;
	}

	public String getPath() {
		return path;
	}

	public boolean connectionClosed() {
		return connectionClosed;
	}

	public String getBody() {
		return body;
	}

	public String getUploadedFileName() {
		return uploadedFileName;
	}

	public String getUploadedFileExtension() {
		return uploadedFileExtension;
	}
}