package webserver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 
 * @author 
 * GetResponse class is to return index.html to client when its comes with GET call
 * http://localhost:8080
 */

public class GetResponse extends Response {

	private final File file;

	public GetResponse(HttpServerThread client, File file) {
		super(client, "200 OK", "");
		this.file = file;
	}

	/**
	 * override the write method of response class and write the index.html content to client
	 */
	@Override
	public void write() throws IOException {

		String[] parts = file.getName().split("\\.");
		super.writeHeader(file.length(), parts[parts.length - 1]);
		FileInputStream in = new FileInputStream(file);
		OutputStream out = super.client.getSocket().getOutputStream();

		int bytesRead = 0;
		while ((bytesRead = in.read(super.client.getBuffer())) != -1) {
			out.write(super.client.getBuffer(), 0, bytesRead);
		}
		in.close();

		System.out.println("Client " + super.client.getClientId() + " got " + file.getName());
	}

}