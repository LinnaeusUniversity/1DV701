package webserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 
 * @author 
 * HttpPostServer to upload image. server will listen and wait in the port 8080
 */
public class HttpPostServer {

	public final static int PORT = 8080;

	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = null;
		try {
			serverSocket = new ServerSocket(PORT);
		} catch (IOException e) {
			System.out.println("ERROR: PORT IS IN USE!!");
			System.exit(1);
		}

		System.out.println("Server Waiting at Port 8080");
		int clientId = 0;
		/*** server will accept client connection and wait till termination ***/
		while (true) {
			Socket socket = serverSocket.accept();
			/*** Thread class to execute for each client ***/
			HttpServerThread client = new HttpServerThread(socket, ++clientId);
			client.start();
		}
	}
}

/**
 * HttpServerThread which extends Thread to handle multiple client using multithreading concept
 */
class HttpServerThread extends Thread {

	private final Socket socket;
	private ResponseFactory responseFactory;
	private RequestParser requestParser;
	private byte[] buffer;
	private final int clientId;
	private final int TIME_OUT_IN_MS = 100000;

	/**
	 * constructor for HttpServerThread to assign client socket connection 
	 * @param socket
	 * @param clientId
	 */
	public HttpServerThread(Socket socket, int clientId) {
			this.socket = socket;
			requestParser = new RequestParser();
			buffer = new byte[9000];
			this.clientId = clientId;
			responseFactory = new ResponseFactory(this);
			System.out.println("Client " + clientId + " connected");
	}

	/**
	 * override threads run method to execute the request and response
	 */
	@Override
	public void run() {

		while (true) {
			try {
				socket.setSoTimeout(TIME_OUT_IN_MS);
				requestParser = requestParser.parse(new BufferedReader(new InputStreamReader(socket.getInputStream())));
				responseFactory.getResponse(requestParser).write();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error " + e.getMessage());
				break;
			}
			if (requestParser.connectionClosed() || requestParser.getMethodType() != Method.MethodType.GET) {
				break;
			}
		}

		try {
			socket.close();
		} catch (IOException e) {
			System.out.println("Error" + e.getMessage());
		}

		System.out.println("Client " + clientId + " disconnected");
	}

	public Socket getSocket() {
		return socket;
	}

	public byte[] getBuffer() {
		return buffer;
	}

	public int getClientId() {
		return clientId;
	}
}

/**
 * 
 * @author 
 * PostResponse class is extends abstract class Response and calls the parent class constructor using super
 */
class PostResponse extends Response {

	public PostResponse(HttpServerThread client, String filename) {
		super(client, "Upload Status", "<h1>The selected file <b>"+ filename + "</b> has been uploaded.</h1>" );
	}
}