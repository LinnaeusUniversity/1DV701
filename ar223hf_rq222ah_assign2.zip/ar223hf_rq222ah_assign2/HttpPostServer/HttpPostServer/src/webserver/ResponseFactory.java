package webserver;

import java.io.IOException;


public class ResponseFactory {

	private Method method;
	private HttpServerThread client;

	public ResponseFactory(HttpServerThread client) {
		method = new Method();
		this.client = client;
	}

	/**
	 * Method to get return response object depends on Get or Post
	 * @param requestParser
	 * @return
	 * @throws IOException
	 * @throws Exception
	 */
	public Response getResponse(RequestParser requestParser)
			throws IOException, Exception {

		System.out.println("requestParser " + requestParser.getMethodType());
		switch (requestParser.getMethodType()) {

		case GET:
			return new GetResponse(client, method.GET(requestParser.getPath()));

		case POST:
			method.POST(requestParser);
			return new PostResponse(client, requestParser.getUploadedFileName());

		default:
			return new PostResponse(client, requestParser.getUploadedFileName());
		}
	}

}