import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.StringTokenizer;

/**
 * 
 * @author 
 * Class HttpWebServer is simple http server which is developed using TCP ServerSocket
 * Each Client Connection will be managed in a dedicated Thread by implementing runnable interface
 */

public class HttpGetServer implements Runnable{ 
	
	static final File WEB_ROOT = new File(".");
	static final String DEFAULT_FILE = "index.html";
	static final String FILE_NOT_FOUND = "404.html";
	static final String REDIRECT_FOUND = "302.html";
	static final String FORBIDDEN_FOUND = "403.html";
	static final String INTERNAL_SERVER_ERROR = "500.html";
	static final String METHOD_NOT_SUPPORTED = "not_supported.html";
	static int userId = 0;
	
	// port to listen connection
	private static int PORT;
	
	// Folder to read html
	private static String folder;
	
	// Client Connection via Socket Class
	private Socket socket;
	
	public HttpGetServer(Socket socket, int userId) {
		this.socket = socket;
		this.userId = userId;
	}
	
	public static void main(String[] args) throws IOException, InterruptedException {
		ServerSocket serverSocket = null;
		try {
			
			if (args.length != 2 && args.length == 0) {
				System.out.println("Error: Please enter PORT and direcotry name");
	            return;
	        }
	 
	        PORT = parseStringToDigit(args[0]);
	        
	        /* Make sure the port number is in the valid range */
	        if (PORT <= 0 || PORT >= 65536) {
	            System.err.println("Port value must be in (0 -> 65535)!");
	            return;
	        }
	        
	        folder = args[1];
	        
			serverSocket = new ServerSocket(PORT);
			System.out.println("Server started. Listening for connections on port : " + PORT + " ...");
			
			/*** To listen until user break the server execution ***/
			while (true) {
				HttpGetServer myServer = new HttpGetServer(serverSocket.accept(),++userId);
				System.out.println("New client connected. (" + new Date() + ")");
				
				/*** created individual thread to support multiple client connection  ***/
				Thread thread = new Thread(myServer);
				thread.start();
			}
			
		} catch (IOException e) {
			System.err.println("Server Connection error : " + e.getMessage());
		}finally {
			if(serverSocket != null)
				serverSocket.close();
		}
	}

	@Override
	public void run() {
		
		System.out.println("[User " + userId + "] [IP " + socket.getInetAddress() + "] [PORT " + socket.getPort() + "]");

		BufferedReader in = null; PrintWriter out = null; BufferedOutputStream dataOut = null;
		String fileRequested = null;
		
		try {
			/*** Read characters from the client via input stream on the socket ***/
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			/*** Get character output stream to client to read headers data ***/
			out = new PrintWriter(socket.getOutputStream());
			/*** get binary output stream to client to write client requested data ***/ 
			dataOut = new BufferedOutputStream(socket.getOutputStream());
			
			/*** read first line of the request from the client ***/
			String input = in.readLine();

			if(input!=null) {
				/*** parse the input using string tokenizer ***/ 
				System.out.println(input);
				StringTokenizer parse = new StringTokenizer(input);
				/*** first token will be Http Method of the request Get or Post or Put ***/
				String method = parse.nextToken().toUpperCase(); 
				/*** Next token will be the file requested from client ***/
				fileRequested = parse.nextToken().toLowerCase();
				System.out.println("fileRequested " + fileRequested);
				/*** read some of the request headers and print ***/
				int count = 0;
				while(count<=5) {
					input = in.readLine();
					System.out.println(input);
					count = count + 1;
				}
				/*** check for Get GET method to support and throw error for other Http methods ***/
				if (!method.equals("GET")) {
					System.out.println("501 Not Implemented : " + method + " method.");
					
					/*** return html file which method not supported error ***/ 
					String path = folder + "/" + METHOD_NOT_SUPPORTED;
					Path filePath =  Paths.get("", path);
					sendResponse(out, dataOut, filePath, "HTTP/1.1 501 Not Implemented");
					return;
					
				} else {
					String path = getFilePath(fileRequested, DEFAULT_FILE);
					Path filePath =  Paths.get("", path);
					File file = new File(path);
					if(file.exists()) {
						System.out.println("File Name " + file.getName());
						/*** to test HTTP 302 code - 302 status indicates that the requested resource should temporarily be accessed at a different URI.  ***/
						if(file.getName().equals(REDIRECT_FOUND)) {
							path = folder + "/" + REDIRECT_FOUND;
							sendResponse(out, dataOut, filePath, "HTTP/1.1 302 Found redirect");
						}
						/*** to test HTTP 403 code - 403 Forbidden Error.  ***/
						else if(file.getName().equals(FORBIDDEN_FOUND)) {
							path = folder + "/" + FORBIDDEN_FOUND;
							sendResponse(out, dataOut, filePath, "HTTP/1.1 403 Forbidden"); 
						}
						/*** to test HTTP 500 code - 500 Internal Server Error.  ***/
						else if(file.getName().equals(INTERNAL_SERVER_ERROR)) {
							path = folder + "/" + INTERNAL_SERVER_ERROR;
							sendResponse(out, dataOut, filePath, "HTTP/1.1 500 Internal Server Error"); 
						}else {
							sendResponse(out, dataOut, filePath, "HTTP/1.1 200 OK");
							String content = guessContentType(filePath);
							System.out.println("File " + fileRequested + " of type " + content + " returned");
						}
					}else {
						path = folder + "/" + FILE_NOT_FOUND;
						filePath =  Paths.get("", path);
						sendResponse(out, dataOut, filePath, "HTTP/1.1 404 File Not Found");
					}
					
				}
			}			
		} catch (FileNotFoundException fnfe) {
			try {
				System.out.println("Error");
				String path = folder + "/" + FILE_NOT_FOUND;
				Path filePath =  Paths.get("", path);
				sendResponse(out, dataOut, filePath, "HTTP/1.1 404 File Not Found");
			} catch (Exception ioe) {
				System.err.println("Error with file not found exception : " + ioe.getMessage());
			}
			
		} catch (IOException ioe) {
			System.err.println("Server error : " + ioe);
		} finally {
			try {
				in.close();
				out.close();
				dataOut.close();
				socket.close(); 
			} catch (Exception e) {
				System.err.println("Error closing stream : " + e.getMessage());
			} 
			
			System.out.println("Connection closed.\n");
		}
		
		
	}
	
	/***
	 * Send response to client
	 * @param out
	 * @param dataOut
	 * @param filePath
	 * @param header
	 * @throws IOException
	 */
	private void sendResponse(PrintWriter out, BufferedOutputStream dataOut, Path filePath, String header) throws IOException {
		/*** read content type to return to client ***/
		String contentMimeType = guessContentType(filePath);
		
		/*** read body content from the files ***/
		byte[] fileData = Files.readAllBytes(filePath);
		int fileLength = fileData.length;
		
		/*** set HTTP Headers with data to send ***/
		out.println(header);
		out.println("Date: " + new Date());
		out.println("Content-type: " + contentMimeType);
		out.println("Content-length: " + fileLength);
		
		/*** add blank line between headers and content in the response ***/
		out.println(); 
		out.flush(); 
		System.out.println("Post");
		/*** write content to the response ***/
		dataOut.write(fileData, 0, fileLength);
		dataOut.flush();
	}
	
	/***
	 * to get file page
	 * @param path
	 * @param fileName
	 * @return
	 */
	private static String getFilePath(String path, String fileName) {
		System.out.println("path=" + path);
		System.out.println("fileName=" + fileName);
		File file = new File(folder + "/" + path);
		System.out.println();
		if(!file.isDirectory()) {
			System.out.println("Inside 11111");
			path = folder + "/" + path;
		}else if(path.endsWith(".html")){
			System.out.println("Inside 22222");
			path = folder + "/" + path;
		}else {
			System.out.println("Inside 33333");
			path = folder + "/" + path + "/" + DEFAULT_FILE;
		}
		        
		System.out.println("Path After = " + path);
		return path;
    }

	/***
	 * To get content type
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
    private static String guessContentType(Path filePath) throws IOException {
        return Files.probeContentType(filePath);
    }
    
	/**
	 * parse String to number
	 * @param input
	 * @return
	 */
	private static int parseStringToDigit(String input) {
		int port = -1;
		try {
			port = Integer.parseInt(input);
		} catch (Exception e) {
			System.out.println("Error: Please enter Numberic value");; 
		}
		return port;
	}
	
}