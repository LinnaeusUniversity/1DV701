import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Properties;

/**
 * 
 * @author 
 *
 * TFTP, the Trivial File Transfer Protocol, is used to upload and download files. 
 * This server is running on localhost port 69. port 69 is default port of file transfer protocol
 *   
 */
public class TrivialFileTransferServer {

	/** predefined port 69 **/
	public static final int TFTP_PORT = 69;
	public static final int BUF_SIZE = 516;
	/*** define data size to read a maximum of 512 bytes from the file ***/
	public static final int DATA_SIZE = 512;
	
	/** If a packet is lost during the transfer, a timeout will occur on the receiver�s  **/
	public static int TIMEOUT = 5000;
	public static int CLIENT_TID;
	public static int SERVER_TID;

	/*** the download and upload directory read from properties file ***/   
	public static String READ_DIR;
	public static String WRITE_DIR;

	int sendCounter = 0;
	private static int RESEND_LIMIT = 5;
	private static long freeSpace;
	
	/*** tftp OP codes ***/
	/***
	 * Opcode	Description	
	 *  1	    RRQ.Read request
	 *  2		WRQ. Write request
	 *  3		DATA. Read or write the next block of data
	 *	4		ACK. Acknowledgment
	 *	5		ERROR. Error message    
	 */
	public static final int OP_RRQ = 1;
	public static final int OP_WRQ = 2;
	public static final int OP_DATA = 3;
	public static final int OP_ACK = 4;
	public static final int OP_ERROR = 5;

	public static void main(String[] args) throws IOException {
		if (args.length > 0) {
			System.err.printf("usage: java %s\n", TrivialFileTransferServer.class.getCanonicalName());
			System.exit(1);
		}
		
		/*** Starting the Trivial File Transfer server ***/
		try {
			TrivialFileTransferServer server = new TrivialFileTransferServer();
			server.start();
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	private void start() throws IOException {
		byte[] buf = new byte[BUF_SIZE];

		/*** Create it creates a datagram socket. Socket to listen on client and receive client address ***/
		DatagramSocket socket = new DatagramSocket(TFTP_PORT);

		/*** binds it with the available Port Number ***/ 
		/*SocketAddress localBindPoint = new InetSocketAddress(TFTP_PORT);
		socket.bind(localBindPoint); */

		System.out.printf("Listening at port %d for new requests\n", TFTP_PORT);

		// Loop to handle client requests
		while (true) {

			Properties prop = new Properties();
			InputStream inputStream = new FileInputStream(new File("config.properties"));
			prop.load(inputStream);
			TIMEOUT = Integer.parseInt(prop.getProperty("timeout"));
			System.out.println("TIMEOUT " + TIMEOUT);
			RESEND_LIMIT = Integer.parseInt(prop.getProperty("resendlimit"));
			System.out.println("RESEND_LIMIT " + RESEND_LIMIT);
			freeSpace = Long.parseLong(prop.getProperty("freespace"));
			//long freeSpace = new File(WRITEDIR).getUsableSpace();
			System.out.println("freeSpace " + freeSpace);
			READ_DIR = prop.getProperty("read_dir");
			System.out.println("freeSpace " + freeSpace);
			WRITE_DIR = prop.getProperty("write_dir");
			System.out.println("freeSpace " + freeSpace);
			
			/*** to get client address ***/
			final InetSocketAddress clientAddress = receiveFrom(socket, buf);

			/*** If clientAddress is null or any an error occurred in receiveFrom() method then continue the loop ***/
			if (clientAddress == null)
				continue;

			/*** to get tftp transfer type ***/ 
			final StringBuffer requestedFile = new StringBuffer();
			@SuppressWarnings("unused")
			final int reqtype = ParseRQ(buf, requestedFile);

			new Thread() {
				public void run() {
					try {
						/*** Creates a datagram socket. This sendSocket to connect with client and download and upload files ***/
						DatagramSocket sendSocket = new DatagramSocket(0);

						/*** Connect to client using retrieved client Address ***/
						sendSocket.connect(clientAddress);
						CLIENT_TID = sendSocket.getPort();
						SERVER_TID = sendSocket.getLocalPort();

						System.out.printf("%s request for %s from %s using port\n",
								(reqtype == OP_RRQ) ? "Read" : "Write", clientAddress.getHostName(),
										clientAddress.getPort());

						/*** if transfer type is read request ***/
						if (reqtype == OP_RRQ) {
							requestedFile.insert(0, READ_DIR);
							System.out.println(requestedFile);
							int block = 0;
							sendCounter = 0;
							boolean result = send_DATA_receive_ACK(sendSocket, requestedFile.toString(), ++block);
							if(result) {
								System.out.println("File: " + requestedFile.toString().split("\0")[0] + " downloaded successfully");
							}
						}
						/*** if transfer type is write request ***/
						else if (reqtype == OP_WRQ) {
							System.out.println("11111");
							requestedFile.insert(0, WRITE_DIR);
							System.out.println("22222");
							int block = 0;
							boolean result = receive_DATA_send_ACK(sendSocket, requestedFile.toString(), block);
							System.out.println("33333 " + result);
							if(result) {
								System.out.println("File: " + requestedFile.toString().split("\0")[0] + " uploaded successfully");
							}
						}
						/*** if transfer type is not read or write then send error ***/
						else {
							System.err.println("Invalid request. Sending an error packet.");
							send_ERR(sendSocket, 4, "Illegal TFTP operation.");
							return;
						}

						sendSocket.close();

					} catch (SocketException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			}.start();
		}
	}

	/***
	 * receive data from Socket
	 * @param socket - to received data from 
	 * @param buf - to store data into
	 * @return InetSocketAddress of the client
	 * @throws IOException
	 */
	private InetSocketAddress receiveFrom(DatagramSocket socket, byte[] buf) throws IOException {
		DatagramPacket packet = new DatagramPacket(buf, buf.length);
		socket.receive(packet);
		return new InetSocketAddress(packet.getAddress(), packet.getPort());
	}

	/**
	 * 
	 * @param buf - read the buf data and append into the String Buffer
	 * @param requestedFile - to read and check the transfer mode
	 * @return opcode Read or Write
	 */
	private int ParseRQ(byte[] buf, StringBuffer requestedFile) {
		ByteBuffer wrap = ByteBuffer.wrap(buf);
		requestedFile.append(new String(buf, 2, buf.length - 2));
		/*** first parameter will be transfer mode. if transfer mode is not octet then print error Invalid Mode. ***/ 
		if (!requestedFile.toString().split("\0")[1].equals("octet")) {
			System.out.println("Invalid mode");
		}
		/*** return the opcode Read or Write ***/
		return wrap.getShort();
	}

	private boolean send_DATA_receive_ACK(DatagramSocket sendSocket, String requestedFile, int block) {

		final File FILE = new File(requestedFile.split("\0")[0]);

		try {
			if (!FILE.exists()) {
				System.out.println("File not found");
				send_ERR(sendSocket, 1, "File not found.");
				return false;

			} else {

				@SuppressWarnings("resource")
				FileInputStream stream = new FileInputStream(FILE);

				while (true) {
					byte[] buffer = new byte[DATA_SIZE];

					int bytesRead = stream.read(buffer);

					ByteBuffer data = ByteBuffer.allocate(BUF_SIZE);
					data.putShort((short) OP_DATA);
					data.putShort((short) block);
					data.put(buffer);

					//int sendCounter = 0;
					//final int RESEND_LIMIT = 5;
					ByteBuffer ack;
					short opcode;
					short blockOrError;

					try {
						sendSocket.setSoTimeout(TIMEOUT);

						do {
							DatagramPacket packet = new DatagramPacket(data.array(), bytesRead + 4);
							sendSocket.send(packet);

							ack = ByteBuffer.allocate(OP_ACK);
							DatagramPacket ackPacket = new DatagramPacket(ack.array(), ack.array().length);
							sendSocket.receive(ackPacket);

							opcode = ack.getShort();
							blockOrError = ack.getShort();

							if (opcode == OP_ERROR) {
								System.out.println("Error code: " + blockOrError + ", " + ack.array().toString().trim());
								send_ERR(sendSocket, 0, "Error packet was received from Client.");
								return false;
								
							} else if (CLIENT_TID != sendSocket.getPort() && SERVER_TID != sendSocket.getLocalPort()) {
								send_ERR(sendSocket, 5, "Unknown transfer ID.");
								return false;
							}
							sendCounter = sendCounter + 1;	
						} while (opcode != OP_ACK && blockOrError != block && sendCounter < RESEND_LIMIT);

					} catch (SocketTimeoutException e) {
						System.out.println("TIMEOUT EXCEPTION");
						send_ERR(sendSocket, 2, "Time out/Access violation.");
						FILE.delete();
						return false;
					}
					System.out.println("sendCounter " + sendCounter);
					if (sendCounter >= RESEND_LIMIT) {
						send_ERR(sendSocket, 0, "Exceeded resend limit.");
						FILE.delete();
						return false;
					}

					else if (bytesRead < 512) {
						break;
					}

					block++;
				}

				stream.close();
				return true;
			}
		} catch (IOException e) {
			try {
				send_ERR(sendSocket, 2, "Access violation.");

			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
	}

	private boolean receive_DATA_send_ACK(DatagramSocket sendSocket, String requestedFile, int block) {


		try {
			/* If file already exists send error packet */
			File file = new File(requestedFile.split("\0")[0]);
			System.out.println(requestedFile.split("\0")[0]);
			System.out.println(file.length());

			if (file.exists() && file.length()!=0) {
				send_ERR(sendSocket, 6, "File already exists.");
				return false;
			} else {
				if(file.length()==0)
					file.delete();
				FileOutputStream output = null;
				try {
					output = new FileOutputStream(requestedFile.split("\0")[0]);
				}catch(FileNotFoundException f) {
					System.out.println("Error Code:2" );
					System.out.println("Error Message:Access violation." );
					send_ERR(sendSocket, 2, "Access violation.");
					return false;
				}
				System.out.println("44444");
				// First ACK
				ByteBuffer ack = ByteBuffer.allocate(OP_ACK);
				ack.putShort((short) OP_ACK);
				ack.putShort((short) block);
				DatagramPacket ackPacket = new DatagramPacket(ack.array(), ack.array().length);
				sendSocket.send(ackPacket);
				System.out.println("55555");
				while (true) {

					try {

						sendSocket.setSoTimeout(TIMEOUT);

						byte[] buffer = new byte[BUF_SIZE];
						DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
						sendSocket.receive(packet);

						ByteBuffer wrapper = ByteBuffer.wrap(packet.getData());
						short opcode = wrapper.getShort();

						if (opcode == OP_DATA) {

							byte[] data = Arrays.copyOfRange(packet.getData(), 4, packet.getLength());

							// Check free space before writing data to disk
							//long freeSpace = new File(WRITE_DIR).getUsableSpace();
							if (freeSpace < data.length) {
								System.out.println("Disk Full error");
								send_ERR(sendSocket, 3, "Disk full or allocation exceeded.");
								System.out.println(file.delete());
								return false;
							}

							output.write(data);
							output.flush();

							ByteBuffer dataACK = ByteBuffer.allocate(OP_ACK);
							dataACK.putShort((short) OP_ACK);
							dataACK.putShort(wrapper.getShort());
							sendSocket.send(new DatagramPacket(dataACK.array(), dataACK.array().length));

							if (data.length < 512) {
								sendSocket.close();
								output.close();
								break;
							}
						} else if (opcode == OP_ERROR) {
							System.out.println("Error code: " + wrapper.getShort() + ", " + wrapper.array().toString().trim());
							return false;
						}

						else {
							System.out.println("INVALID OPCODE FROM CLIENT");
							return false;
						}

					} catch (SocketTimeoutException e) {
						System.out.println("TIMEOUT");
						send_ERR(sendSocket, 2, "Time out/Access violation.");
						return false;
					}catch (Exception e) {
						//System.out.println("TIMEOUT");
						//send_ERR(sendSocket, 2, "Time out/Access violation.");
						e.printStackTrace();
						return false;
					}
				}
				return true;
			}

		} catch (IOException e) {
			try {
				send_ERR(sendSocket, 2, "Access violation.");

			} catch (Exception e2) {
				e2.printStackTrace();
			}
			return false;
		}
	}

	/***
	 * 
	 * @param sendSocket - to send error packet
	 * @param errorCode - transfer error code
	 * @param errorMessage - error message to send
	 * @throws IOException
	 */
	private void send_ERR(DatagramSocket sendSocket, int errorCode, String errorMessage) throws IOException {

		ByteBuffer err = ByteBuffer.allocate(errorMessage.length() + OP_ERROR);
		err.putShort((short) OP_ERROR);
		err.putShort((short) errorCode);
		err.put(errorMessage.getBytes());

		DatagramPacket errPacket = new DatagramPacket(err.array(), err.array().length);
		sendSocket.send(errPacket);
	}
}