# TFTP - Trivial File Transfer Protocol

TFTP is a simple file transfer protocol which allows a client to get or put a file onto a remote host.

TFTP protocol supports five types of packets

| **Opcode** | **Packet Type**                 | **Description**        |
| ---------- | ------------------------------- | ---------------------- |
| 1          | RRQ (**R**ead **r**e**q**uest)  | Read access request    |
| 2          | WRQ (**W**rite **r**e**q**uest) | Write access request   |
| 3          | DATA (Data)                     | Data packet            |
| 4          | ACK (**Ack**nowledgment)        | Acknowledgment message |
| 5          | ERROR (Error)                   | Error message          |

**Download TFTP client:**

[TFTP server (jounin.net)](http://tftpd32.jounin.net/tftpd32_download.html)

**Problem 1**

1. Run the TrivialFileTransferServer

   ![image-20210310195059412](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210310195059412.png)

2. Start the TFTP client

   ![image-20210313162421819](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313162421819.png)

3. Enter host as `Localhost`

4. Enter Local File from where we have to upload 

5. Enter remote file from where we have to download

6. Remote file will be from our downloads folder `tftp/downloads`

7. Uploaded file will be stored in `tftp/uploads` using `PUT`

8. Download file will be stored in selected local file path  using `GET`

9. Below is `GET` Example

   Remote File - Test1.txt from `tftp/downloads` 

![image-20210313162911843](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313162911843.png)

![image-20210313162948759](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313162948759.png)

![image-20210313163018102](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163018102.png)

10. Below is `PUT` Example

![image-20210313163339232](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163339232.png)

![image-20210313163322898](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163322898.png)

![image-20210313163428790](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163428790.png)

**VG Problem 2** - Test Timeout and Retry

To test timeout and Retry update the `config.properties` file

1. Update the `config.properties` file to minimum timeout period and download big file.

   ![image-20210313163825710](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163825710.png)

![image-20210313163948001](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163948001.png)

![image-20210313163924254](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313163924254.png)

2. Update the `config.properties` file to minimum `resendlimit` and download big file.

![image-20210313164724756](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313164724756.png)

![image-20210313164837973](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313164837973.png)



![image-20210313164707573](C:\Users\gopal\AppData\Roaming\Typora\typora-user-images\image-20210313164707573.png)

