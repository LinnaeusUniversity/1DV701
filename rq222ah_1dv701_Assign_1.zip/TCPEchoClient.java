/*
  TCPEchoClient.java

*/

import java.io.IOException;
import java.net.*;
import java.util.Arrays;

public class TCPEchoClient extends Thread {
    public static int BUFSIZE;
    public static int MYPORT;
    public static final String MSG = "Good Bye!";
    public static int MSGTRASFERRATE = -1;
    public static String HOST;
    public static int PORT = 0;

    public static boolean isValidInet4Address(String ip) {
        String[] groups = ip.split("\\.");

        if (groups.length != 4)
            return false;

        try {
            return Arrays.stream(groups)
                    .map(Integer::parseInt)
                    .filter(i -> (i >= 0 && i <= 255))
                    .count() == 4;

        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void main(String[] args) throws IOException {

        if (args.length <= 2) {
            System.err.printf("usage: %s server_name port\n", args[1]);
            System.exit(1);
        }
        BUFSIZE = Integer.parseInt(args[2]);
        byte[] buf = new byte[BUFSIZE];

        MSGTRASFERRATE = Integer.parseInt(args[3]);
        HOST = args[0];
        PORT = Integer.parseInt(args[1]);


        if (!isValidInet4Address(args[0])) {
            System.out.println("Invalid IP");
        }

        try {
            if (Integer.parseInt(args[1]) <= 0 || Integer.parseInt(args[1]) > 65535) {
                System.out.println("Invalid Port.");
            }
        } catch (Exception ex) {
            System.out.println("Invalid Port.");
        }

        if (BUFSIZE <= 0) {
            System.out.println("Invalid Buffer.");
        }

        if (MSGTRASFERRATE <= 0) {
            System.out.println("Invalid Message Transfer Rate.");
        }


        TCPEchoClient client = new TCPEchoClient();

        client.start();

    }

    public void run() {
        byte[] buf = new byte[BUFSIZE];
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket(null);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        /* Create local endpoint using bind() */
        SocketAddress localBindPoint = new InetSocketAddress(MYPORT);
        try {
            assert socket != null;
            socket.bind(localBindPoint);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        /* Create remote endpoint */
        SocketAddress remoteBindPoint =
                new InetSocketAddress(HOST,
                        PORT);

        /* Create datagram packet for sending message */
        DatagramPacket sendPacket =
                new DatagramPacket(MSG.getBytes(),
                        MSG.length(),
                        remoteBindPoint);

        /* Create datagram packet for receiving echoed message */
        DatagramPacket receivePacket = new DatagramPacket(buf, buf.length);
        try {
            int i = MSGTRASFERRATE;
            do {
                socket.send(sendPacket);
                System.out.printf("Sent Packet %d.\n", MSGTRASFERRATE - i);
                i--;
            } while (i > 0);


            i = MSGTRASFERRATE;
            do {
                socket.receive(receivePacket);
                System.out.printf("Received Packet %d.\n", MSGTRASFERRATE - i);
                String receivedString =
                        new String(receivePacket.getData(),
                                receivePacket.getOffset(),
                                receivePacket.getLength());
                if (receivedString.compareTo(MSG) == 0)
                    System.out.printf("%d bytes sent and received\n", receivePacket.getLength());
                else
                    System.out.printf("Sent and received msg not equal!\n");
                i--;
            } while (i > 0);

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            socket.close();
        }
    }
}