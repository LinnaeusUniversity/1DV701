/*
  TCPEchoServer.java
  A simple echo server with no error handling
*/

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;


public class TCPEchoServer {
    public static final int BUFSIZE = 1024;
    public static final int MYPORT = 4950;

    public static void main(String[] args) throws IOException {

        if (args.length != 1) {
            System.err.printf("No buffsize provided\n");
            System.exit(1);
        }

        int bufsize = Integer.parseInt(args[0]);
        byte[] buf = new byte[bufsize];



        /* Create socket */
        DatagramSocket socket = new DatagramSocket(null);

        /* Create local bind point */
        SocketAddress localBindPoint = new InetSocketAddress(MYPORT);
        try {
            socket.bind(localBindPoint);
        } catch (BindException e) {
            System.out.println("Unable to bind the local port.");
            System.exit(1);
        }
        ArrayList<String> clients = new ArrayList<String>();
        int client_number = 0;
        while (true) {
            /* Create datagram packet for receiving message */
            DatagramPacket receivePacket = new DatagramPacket(buf, buf.length);

            /* Receiving message */
            socket.receive(receivePacket);

            /* Create datagram packet for sending message */
            DatagramPacket sendPacket =
                    new DatagramPacket(receivePacket.getData(),
                            receivePacket.getLength(),
                            receivePacket.getAddress(),
                            receivePacket.getPort());
            String clientAddress = receivePacket.getAddress().toString() + String.valueOf(receivePacket.getPort());
            if (!clients.contains(clientAddress)) {
                client_number++;
                clients.add(clientAddress);
            }

            /* Send message*/
            socket.send(sendPacket);
            System.out.printf("[Client %d] TCP echo request from Address: %s, Port: %s.\n", client_number, receivePacket.getAddress().getHostAddress(), receivePacket.getPort());
        }
    }
}