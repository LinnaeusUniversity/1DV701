/*
  UDPEchoClient.java

*/

import java.io.IOException;
import java.net.*;
import java.util.Arrays;


public class UDPEchoClient {
    public static int MYPORT = 4950;
    public int client = 1;
    public static final String MSG = "Good Bye!";

    public static boolean isValidInet4Address(String ip) {
        String[] groups = ip.split("\\.");

        if (groups.length != 4)
            return false;

        try {
            return Arrays.stream(groups)
                    .map(Integer::parseInt)
                    .filter(i -> (i >= 0 && i <= 255))
                    .count() == 4;

        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void main(String[] args) throws IOException {

        if (args.length != 4) {
            System.err.printf("usage: %s server_name port\n", args[1]);
            System.exit(1);
        }
        int bufsize = Integer.parseInt(args[2]);
        byte[] buf = new byte[bufsize];

        int msgtransrate = Integer.parseInt(args[3]);

        if (!isValidInet4Address(args[0])) {
            System.out.println("Invalid IP");
        }

        try {
            if (Integer.parseInt(args[1]) <= 0 || Integer.parseInt(args[1]) > 65535) {
                System.out.println("Invalid Port.");
            }
        } catch (Exception ex) {
            System.out.println("Invalid Port.");
        }

        if (bufsize <= 0) {
            System.out.println("Invalid Buffer.");
        }

        boolean flag = true;
        if (msgtransrate <= 0) {
            if (msgtransrate == 0) {
                flag = false;
            }
            System.out.println("Invalid Message Transfer Rate.");
        }

        /* Create socket */
        DatagramSocket socket = new DatagramSocket(null);

        /* Create local endpoint using bind() */
        SocketAddress localBindPoint = new InetSocketAddress(MYPORT);
        try {
            socket.bind(localBindPoint);
        } catch (BindException e) {
            System.out.println("Unable to bind the local port.");
            System.exit(1);
        }

        /* Create remote endpoint */
        SocketAddress remoteBindPoint =
                new InetSocketAddress(args[0],
                        Integer.parseInt(args[1]));

        /* Create datagram packet for sending message */
        DatagramPacket sendPacket =
                new DatagramPacket(MSG.getBytes(),
                        MSG.length(),
                        remoteBindPoint);

        /* Create datagram packet for receiving echoed message */
        DatagramPacket receivePacket = new DatagramPacket(buf, buf.length);

        /* Send and receive message*/
        try {
            do {
                int i = msgtransrate;
                do {
                    socket.send(sendPacket);
                    System.out.printf("Sent Packet %d.\n", msgtransrate - i);
                    i--;
                } while (i > 0);


                i = msgtransrate;
                do {
                    socket.receive(receivePacket);
                    System.out.printf("Received Packet %d.\n", msgtransrate - i);
                    String receivedString =
                            new String(receivePacket.getData(),
                                    receivePacket.getOffset(),
                                    receivePacket.getLength());
                    if (receivedString.compareTo(MSG) == 0)
                        System.out.printf("%d bytes sent and received\n", receivePacket.getLength());
                    else
                        System.out.printf("Sent and received msg not equal!\n");
                    i--;
                } while (i > 0);

                System.out.printf("Delay: 1 sec.\n");
                Thread.sleep(30000);
            } while (flag);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            socket.close();
        }
        /* Compare sent and received message */

    }
}